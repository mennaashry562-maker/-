import 'package:flutter/material.dart';
import '../services/progress_service.dart';

class ProgressScreen extends StatefulWidget {
  final int totalLessons;
  final ProgressService progressService;

  const ProgressScreen({
    super.key,
    required this.totalLessons,
    required this.progressService,
  });

  @override
  State<ProgressScreen> createState() => _ProgressScreenState();
}

class _ProgressScreenState extends State<ProgressScreen> {
  Set<String> completed = {};

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final value = await widget.progressService.completedLessons();
    if (!mounted) return;
    setState(() => completed = value);
  }

  @override
  Widget build(BuildContext context) {
    final progress = widget.totalLessons == 0
        ? 0.0
        : completed.length / widget.totalLessons;

    return Scaffold(
      appBar: AppBar(title: const Text('مستواي')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(22),
              child: Column(
                children: [
                  const Icon(Icons.emoji_events_rounded, size: 52),
                  const SizedBox(height: 12),
                  Text(
                    '${(progress * 100).round()}%',
                    style: const TextStyle(
                        fontSize: 34, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 8),
                  LinearProgressIndicator(
                    value: progress,
                    minHeight: 12,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'أنهيت ${completed.length} من ${widget.totalLessons} درسًا في النسخة الحالية.',
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Card(
            child: ListTile(
              leading: Icon(Icons.lightbulb_outline_rounded),
              title: Text('اقتراح المستوى'),
              subtitle: Text(
                'بعد إضافة اختبارات أكثر، سيقترح التطبيق تلقائيًا القواعد التي تحتاج مراجعة.',
              ),
            ),
          ),
        ],
      ),
    );
  }
}
