import 'package:flutter/material.dart';
import '../data/lessons.dart';
import '../models/lesson.dart';
import 'lesson_screen.dart';

class StagesScreen extends StatelessWidget {
  const StagesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final Map<String, List<GrammarLesson>> grouped = {};
    for (final lesson in lessons) {
      grouped.putIfAbsent(lesson.stage, () => []).add(lesson);
    }

    return Scaffold(
      appBar: AppBar(title: const Text('المراحل والدروس')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: grouped.entries.map((entry) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: Card(
              child: ExpansionTile(
                leading: const Icon(Icons.school_rounded),
                title: Text(
                  'المرحلة ${entry.key}',
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
                children: entry.value.map((lesson) {
                  return ListTile(
                    title: Text(lesson.title),
                    subtitle: Text('${lesson.grade} • ${lesson.unit}'),
                    trailing: const Icon(Icons.chevron_left),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => LessonScreen(lesson: lesson),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}
