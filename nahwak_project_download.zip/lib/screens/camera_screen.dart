import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'analyze_screen.dart';

class CameraScreen extends StatefulWidget {
  const CameraScreen({super.key});

  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> {
  File? imageFile;

  Future<void> pick(ImageSource source) async {
    final x = await ImagePicker().pickImage(
      source: source,
      imageQuality: 85,
    );
    if (x == null) return;
    setState(() => imageFile = File(x.path));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تصوير قطعة نحوية')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                children: [
                  const Icon(Icons.document_scanner_rounded, size: 58),
                  const SizedBox(height: 12),
                  const Text(
                    'اختر صورة من المعرض أو التقط صورة جديدة',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontSize: 18, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'في النسخة الحالية يمكن اختيار الصورة. استخراج النص العربي منها سيُضاف في المرحلة التالية عبر OCR عربي.',
                    textAlign: TextAlign.center,
                    style: TextStyle(height: 1.5),
                  ),
                  const SizedBox(height: 16),
                  Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    alignment: WrapAlignment.center,
                    children: [
                      FilledButton.icon(
                        onPressed: () => pick(ImageSource.camera),
                        icon: const Icon(Icons.camera_alt_rounded),
                        label: const Text('الكاميرا'),
                      ),
                      OutlinedButton.icon(
                        onPressed: () => pick(ImageSource.gallery),
                        icon: const Icon(Icons.photo_library_rounded),
                        label: const Text('المعرض'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          if (imageFile != null) ...[
            const SizedBox(height: 16),
            ClipRRect(
              borderRadius: BorderRadius.circular(18),
              child: Image.file(imageFile!, height: 260, fit: BoxFit.cover),
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const AnalyzeScreen()),
              ),
              icon: const Icon(Icons.spellcheck_rounded),
              label: const Padding(
                padding: EdgeInsets.symmetric(vertical: 14),
                child: Text('الانتقال للتحليل اليدوي حاليًا'),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
