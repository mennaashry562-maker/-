import 'package:flutter/material.dart';
import '../models/lesson.dart';
import '../services/progress_service.dart';
import 'quiz_screen.dart';

class LessonScreen extends StatelessWidget {
  final GrammarLesson lesson;

  const LessonScreen({super.key, required this.lesson});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(lesson.title)),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Text(
            '${lesson.stage} • ${lesson.grade}',
            style: TextStyle(
              color: Theme.of(context).colorScheme.primary,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Text(
                lesson.explanation,
                style: const TextStyle(fontSize: 17, height: 1.8),
              ),
            ),
          ),
          const SizedBox(height: 18),
          const Text('أمثلة',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          ...lesson.examples.map(
            (e) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Card(
                child: ListTile(
                  leading: const Icon(Icons.check_circle_outline_rounded),
                  title: Text(e, style: const TextStyle(fontSize: 17)),
                ),
              ),
            ),
          ),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: () async {
              final result = await Navigator.push<bool>(
                context,
                MaterialPageRoute(
                  builder: (_) => QuizScreen(lesson: lesson),
                ),
              );
              if (result == true && context.mounted) {
                await ProgressService().markCompleted(lesson.id);
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('تم حفظ تقدمك في هذا الدرس ✅'),
                    ),
                  );
                }
              }
            },
            icon: const Icon(Icons.quiz_rounded),
            label: const Padding(
              padding: EdgeInsets.symmetric(vertical: 14),
              child: Text('ابدأ التدريب'),
            ),
          ),
        ],
      ),
    );
  }
}
