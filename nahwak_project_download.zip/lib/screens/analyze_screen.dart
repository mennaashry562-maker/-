import 'package:flutter/material.dart';
import '../services/grammar_service.dart';

class AnalyzeScreen extends StatefulWidget {
  const AnalyzeScreen({super.key});

  @override
  State<AnalyzeScreen> createState() => _AnalyzeScreenState();
}

class _AnalyzeScreenState extends State<AnalyzeScreen> {
  final controller = TextEditingController();
  GrammarAnalysisResult? result;
  bool loading = false;

  Future<void> analyze() async {
    setState(() => loading = true);
    final value = await GrammarService().analyze(controller.text);
    if (!mounted) return;
    setState(() {
      result = value;
      loading = false;
    });
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('المصحح الإعرابي')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          TextField(
            controller: controller,
            minLines: 4,
            maxLines: 8,
            textDirection: TextDirection.rtl,
            decoration: InputDecoration(
              hintText: 'مثال: إنَّ الطالبُ مجتهدٌ',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(18),
              ),
              filled: true,
            ),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: loading ? null : analyze,
            icon: const Icon(Icons.auto_fix_high_rounded),
            label: Padding(
              padding: const EdgeInsets.symmetric(vertical: 14),
              child: Text(loading ? 'جارٍ التحليل...' : 'حلل وصحح'),
            ),
          ),
          if (result != null) ...[
            const SizedBox(height: 20),
            const Text(
              'التحليل',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 10),
            ...result!.items.map(
              (item) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Card(
                  child: ListTile(
                    title: Text(item.token,
                        style: const TextStyle(fontWeight: FontWeight.w800)),
                    subtitle: Text(
                      '${item.analysis}${item.correction != null ? "\nالتصحيح المقترح: ${item.correction}" : ""}',
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 10),
            ...result!.notes.map(
              (n) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Text('• $n'),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
