import 'package:flutter/material.dart';
import '../models/lesson.dart';

class QuizScreen extends StatefulWidget {
  final GrammarLesson lesson;

  const QuizScreen({super.key, required this.lesson});

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  int? selected;
  bool checked = false;

  @override
  Widget build(BuildContext context) {
    final q = widget.lesson.questions.first;
    final isCorrect = selected == q.answerIndex;

    return Scaffold(
      appBar: AppBar(title: const Text('تدريب')),
      body: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              q.prompt,
              style: const TextStyle(
                  fontSize: 22, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 20),
            ...List.generate(q.choices.length, (i) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Card(
                  child: RadioListTile<int>(
                    value: i,
                    groupValue: selected,
                    title: Text(q.choices[i]),
                    onChanged:
                        checked ? null : (v) => setState(() => selected = v),
                  ),
                ),
              );
            }),
            if (checked) ...[
              const SizedBox(height: 14),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(
                    '${isCorrect ? "إجابة صحيحة ✅" : "إجابة غير صحيحة ❌"}\n${q.explanation}',
                    style: const TextStyle(fontSize: 16, height: 1.6),
                  ),
                ),
              ),
            ],
            const Spacer(),
            FilledButton(
              onPressed: selected == null
                  ? null
                  : () {
                      if (!checked) {
                        setState(() => checked = true);
                      } else if (isCorrect) {
                        Navigator.pop(context, true);
                      } else {
                        setState(() {
                          selected = null;
                          checked = false;
                        });
                      }
                    },
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 14),
                child: Text(
                  !checked
                      ? 'تحقق من الإجابة'
                      : (isCorrect ? 'إنهاء' : 'حاول مرة أخرى'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
