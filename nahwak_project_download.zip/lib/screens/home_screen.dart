import 'package:flutter/material.dart';
import '../data/lessons.dart';
import '../services/progress_service.dart';
import 'stages_screen.dart';
import 'analyze_screen.dart';
import 'camera_screen.dart';
import 'progress_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int index = 0;

  void openProgress() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ProgressScreen(
          totalLessons: lessons.length,
          progressService: ProgressService(),
        ),
      ),
    );
  }

  Widget feature({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Row(
            children: [
              CircleAvatar(
                radius: 26,
                backgroundColor: Theme.of(context).colorScheme.primaryContainer,
                child: Icon(icon, size: 28),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: const TextStyle(
                            fontSize: 18, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: TextStyle(
                          color: Colors.grey.shade700, height: 1.4),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_left),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('نحوُك',
            style: TextStyle(fontWeight: FontWeight.w900)),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Theme.of(context).colorScheme.primary,
                  Theme.of(context).colorScheme.tertiary,
                ],
              ),
              borderRadius: BorderRadius.circular(28),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.auto_stories_rounded,
                    color: Colors.white, size: 42),
                SizedBox(height: 14),
                Text(
                  'اتعلّم النحو خطوة بخطوة',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  'نسخة أولى للمنهج المصري: دروس، تدريبات، تتبع تقدم، وتحليل إعرابي مبدئي.',
                  style: TextStyle(
                      color: Colors.white, fontSize: 15, height: 1.5),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          feature(
            icon: Icons.school_rounded,
            title: 'المراحل والدروس',
            subtitle: 'ابتدائي • إعدادي • ثانوي',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const StagesScreen()),
            ),
          ),
          const SizedBox(height: 12),
          feature(
            icon: Icons.spellcheck_rounded,
            title: 'المصحح الإعرابي',
            subtitle: 'اكتب جملة واعرض التحليل والتصحيح المقترح',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const AnalyzeScreen()),
            ),
          ),
          const SizedBox(height: 12),
          feature(
            icon: Icons.document_scanner_rounded,
            title: 'تصوير قطعة نحوية',
            subtitle: 'واجهة جاهزة لاختيار صورة، وسيضاف OCR العربي في المرحلة التالية',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const CameraScreen()),
            ),
          ),
          const SizedBox(height: 12),
          feature(
            icon: Icons.insights_rounded,
            title: 'مستواي',
            subtitle: 'تابع الدروس المنجزة ونسبة تقدمك',
            onTap: openProgress,
          ),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) {
          setState(() => index = value);
          if (value == 1) openProgress();
        },
        destinations: const [
          NavigationDestination(
              icon: Icon(Icons.home_rounded), label: 'الرئيسية'),
          NavigationDestination(
              icon: Icon(Icons.insights_rounded), label: 'مستواي'),
          NavigationDestination(
              icon: Icon(Icons.settings_rounded), label: 'الإعدادات'),
        ],
      ),
    );
  }
}
