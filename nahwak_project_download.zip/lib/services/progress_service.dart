import 'package:shared_preferences/shared_preferences.dart';

class ProgressService {
  static const _completedKey = 'completed_lessons';

  Future<Set<String>> completedLessons() async {
    final prefs = await SharedPreferences.getInstance();
    return (prefs.getStringList(_completedKey) ?? []).toSet();
  }

  Future<void> markCompleted(String lessonId) async {
    final prefs = await SharedPreferences.getInstance();
    final ids = (prefs.getStringList(_completedKey) ?? []).toSet();
    ids.add(lessonId);
    await prefs.setStringList(_completedKey, ids.toList());
  }
}
