class AnalysisItem {
  final String token;
  final String analysis;
  final String? correction;

  const AnalysisItem(this.token, this.analysis, {this.correction});
}

class GrammarAnalysisResult {
  final List<AnalysisItem> items;
  final List<String> notes;

  const GrammarAnalysisResult(this.items, this.notes);
}

class GrammarService {
  static const particles = <String>{
    'إن', 'إنَّ', 'أن', 'أنَّ', 'كأن', 'كأنَّ',
    'لكن', 'لكنَّ', 'لعل', 'لعلَّ', 'ليت'
  };

  Future<GrammarAnalysisResult> analyze(String text) async {
    final normalized = text.trim();
    if (normalized.isEmpty) {
      return const GrammarAnalysisResult([], ['اكتب جملة أولًا.']);
    }

    final tokens = normalized
        .replaceAll(RegExp(r'[،؛؟.!]'), '')
        .split(RegExp(r'\s+'));

    final items = <AnalysisItem>[];

    for (var i = 0; i < tokens.length; i++) {
      final t = tokens[i];
      String analysis = 'تحليل أولي يعتمد على السياق';
      String? correction;

      if (i == 0 && particles.contains(t)) {
        analysis = 'حرف ناسخ مبني لا محل له من الإعراب';
      } else if (i == 1 && particles.contains(tokens.first)) {
        analysis = 'اسم الحرف الناسخ: منصوب';
        if (t.endsWith('ُ')) {
          correction = '${t.substring(0, t.length - 1)}َ';
        }
      } else if (i == 0 && t.startsWith('ال')) {
        analysis = 'اسم معرف بأل؛ قد يكون مبتدأً بحسب السياق';
      } else if (i > 0 && tokens.first.endsWith('َ')) {
        analysis = 'قد يكون من مكونات الجملة الفعلية؛ يحتاج السياق لتحديد الوظيفة بدقة';
      }

      items.add(AnalysisItem(t, analysis, correction: correction));
    }

    return GrammarAnalysisResult(
      items,
      [
        'النسخة الحالية تعرض تحليلًا تعليميًا مبدئيًا.',
        'المرحلة التالية ستربط التطبيق بمحرك إعراب ذكي على خادم آمن لزيادة الدقة.',
      ],
    );
  }
}
