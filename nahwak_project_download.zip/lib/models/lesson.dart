class GrammarQuestion {
  final String prompt;
  final List<String> choices;
  final int answerIndex;
  final String explanation;

  const GrammarQuestion({
    required this.prompt,
    required this.choices,
    required this.answerIndex,
    required this.explanation,
  });
}

class GrammarLesson {
  final String id;
  final String title;
  final String stage;
  final String grade;
  final String unit;
  final String explanation;
  final List<String> examples;
  final List<GrammarQuestion> questions;

  const GrammarLesson({
    required this.id,
    required this.title,
    required this.stage,
    required this.grade,
    required this.unit,
    required this.explanation,
    required this.examples,
    required this.questions,
  });
}
